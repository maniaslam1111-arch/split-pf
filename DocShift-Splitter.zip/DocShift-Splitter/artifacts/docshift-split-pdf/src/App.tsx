import { type ReactNode, useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
import { ErrorBoundary } from '@/components/error-boundary';
import { Toaster } from '@/components/ui/toaster';
import { TooltipProvider } from '@/components/ui/tooltip';
import NotFound from '@/pages/not-found';
import { PDFDocument } from 'pdf-lib';
import JSZip from 'jszip';
import {
  AlertCircle, ArrowDownToLine, Check, FileText, Files, LockKeyhole,
  Package, ShieldCheck, UploadCloud, X,
} from 'lucide-react';
import { Route, Switch, useLocation, Router as WouterRouter } from 'wouter';

const queryClient = new QueryClient();
type SplitMode = 'pages' | 'ranges' | 'count';
type SplitFile = { name: string; size: number; url: string };

function Home() {
  const inputRef = useRef<HTMLInputElement>(null);
  const urlsRef = useRef<string[]>([]);
  const [file, setFile] = useState<File | null>(null);
  const [pageCount, setPageCount] = useState<number | null>(null);
  const [mode, setMode] = useState<SplitMode>('pages');
  const [ranges, setRanges] = useState('');
  const [pagesPerFile, setPagesPerFile] = useState('2');
  const [error, setError] = useState('');
  const [dragging, setDragging] = useState(false);
  const [parsing, setParsing] = useState(false);
  const [splitting, setSplitting] = useState(false);
  const [progress, setProgress] = useState(0);
  const [results, setResults] = useState<SplitFile[]>([]);
  const [zipUrl, setZipUrl] = useState('');

  const revokeUrls = useCallback(() => {
    urlsRef.current.forEach(URL.revokeObjectURL);
    urlsRef.current = [];
  }, []);
  useEffect(() => () => revokeUrls(), [revokeUrls]);

  const reset = useCallback(() => {
    revokeUrls();
    setFile(null);
    setPageCount(null);
    setResults([]);
    setZipUrl('');
    setProgress(0);
    setError('');
    setParsing(false);
    setSplitting(false);
    if (inputRef.current) inputRef.current.value = '';
  }, [revokeUrls]);

  const selectFile = async (selected?: File) => {
    if (!selected) return;
    reset();
    if (selected.size > 200 * 1024 * 1024) {
      setError('This file is larger than 200 MB. Choose a smaller PDF to continue.');
      return;
    }
    if (selected.type !== 'application/pdf' && !selected.name.toLowerCase().endsWith('.pdf')) {
      setError('That file does not appear to be a PDF. Choose a file with a .pdf extension.');
      return;
    }
    setFile(selected);
    setParsing(true);
    try {
      const pdf = await PDFDocument.load(await selected.arrayBuffer(), { updateMetadata: false });
      const count = pdf.getPageCount();
      if (!count) throw new Error('No pages');
      setPageCount(count);
    } catch {
      setFile(null);
      setError('We couldn’t read this PDF. It may be damaged, encrypted, or unsupported. Try another PDF.');
    } finally {
      setParsing(false);
    }
  };

  const groups = useMemo((): number[][] | null => {
    if (!pageCount) return null;
    if (mode === 'pages') return Array.from({ length: pageCount }, (_, i) => [i + 1]);
    if (mode === 'count') {
      if (!/^[1-9]\d*$/.test(pagesPerFile)) return null;
      const size = Number(pagesPerFile);
      if (!Number.isSafeInteger(size)) return null;
      const chunks: number[][] = [];
      for (let start = 1; start <= pageCount; start += size) {
        chunks.push(Array.from({ length: Math.min(size, pageCount - start + 1) }, (_, i) => start + i));
      }
      return chunks;
    }
    if (!ranges.trim()) return null;
    const used = new Set<number>();
    const output: number[][] = [];
    for (const raw of ranges.split(',')) {
      const match = raw.trim().match(/^(\d+)(?:\s*-\s*(\d+))?$/);
      if (!match) return null;
      const start = Number(match[1]);
      const end = Number(match[2] ?? match[1]);
      if (!Number.isSafeInteger(start) || !Number.isSafeInteger(end) || start < 1 || end < start || end > pageCount) return null;
      const group: number[] = [];
      for (let page = start; page <= end; page += 1) {
        if (used.has(page)) return null;
        used.add(page);
        group.push(page);
      }
      output.push(group);
    }
    return output.length ? output : null;
  }, [mode, pageCount, pagesPerFile, ranges]);

  const rangeError = mode === 'ranges' && pageCount && !groups
    ? ranges.trim()
      ? `Enter valid, non-overlapping page ranges between 1 and ${pageCount}, separated by commas.`
      : 'Add at least one page or range to continue.'
    : '';
  const countError = mode === 'count' && !/^[1-9]\d*$/.test(pagesPerFile)
    ? 'Enter a positive whole number.' : '';

  const splitPdf = async () => {
    if (!file || !pageCount || !groups?.length || splitting) return;
    revokeUrls();
    setResults([]);
    setZipUrl('');
    setError('');
    setSplitting(true);
    setProgress(0);
    try {
      const source = await PDFDocument.load(await file.arrayBuffer(), { updateMetadata: false });
      const outputs: SplitFile[] = [];
      const zip = new JSZip();
      const base = file.name.replace(/\.pdf$/i, '').replace(/[^\w.-]+/g, '_') || 'document';
      for (let i = 0; i < groups.length; i += 1) {
        const group = groups[i];
        const part = await PDFDocument.create();
        const copiedPages = await part.copyPages(source, group.map((page) => page - 1));
        copiedPages.forEach((page) => part.addPage(page));
        const bytes = await part.save();
        const blob = new Blob([bytes.slice().buffer as ArrayBuffer], { type: 'application/pdf' });
        const suffix = mode === 'pages' ? `page-${group[0]}` : mode === 'ranges'
          ? `part-${i + 1}` : `pages-${group[0]}-${group[group.length - 1]}`;
        const name = `${base}_${suffix}.pdf`;
        const url = URL.createObjectURL(blob);
        urlsRef.current.push(url);
        outputs.push({ name, size: blob.size, url });
        zip.file(name, bytes);
        setProgress(Math.round(((i + 1) / groups.length) * 90));
        await new Promise<void>((resolve) => window.setTimeout(resolve, 0));
      }
      setResults(outputs);
      const archive = await zip.generateAsync({ type: 'blob' }, ({ percent }) => {
        setProgress(90 + Math.round(percent / 10));
      });
      const archiveUrl = URL.createObjectURL(archive);
      urlsRef.current.push(archiveUrl);
      setZipUrl(archiveUrl);
      setProgress(100);
    } catch {
      revokeUrls();
      setError('Splitting didn’t complete. This PDF may contain unsupported content. Try a different split option or another file.');
      setResults([]);
      setZipUrl('');
    } finally {
      setSplitting(false);
    }
  };

  const download = (url: string, name: string) => {
    const anchor = document.createElement('a');
    anchor.href = url;
    anchor.download = name;
    document.body.appendChild(anchor);
    anchor.click();
    anchor.remove();
  };
  const sizeLabel = (size: number) => size < 1024 * 1024
    ? `${Math.max(1, Math.round(size / 1024))} KB`
    : `${(size / (1024 * 1024)).toFixed(1)} MB`;
  const selectMode = (value: SplitMode) => setMode(value);

  return (
    <div className="app-shell">
      <header className="topbar"><div className="topbar-inner">
        <div className="brand"><span className="brand-mark"><Files size={18} strokeWidth={2.4} /></span>DocShift</div>
        <div className="privacy-pill"><LockKeyhole size={13} /> Private by design</div>
      </div></header>
      <main className="main-content">
        <div className="intro">
          <p className="eyebrow">A clearer way to work with PDFs</p>
          <h1>Split PDF pages in seconds.</h1>
          <p>Separate pages or choose exactly what goes together. Your document stays right here on your device.</p>
        </div>
        <section className="workspace" aria-label="PDF splitter">
          <input ref={inputRef} className="file-input" type="file" accept="application/pdf,.pdf" aria-label="Choose a PDF file" data-testid="input-pdf-file" onChange={(event) => void selectFile(event.target.files?.[0])} />
          {!file ? <div
            className={`dropzone${dragging ? ' is-dragging' : ''}`}
            role="button" tabIndex={0}
            aria-label="Upload a PDF. Drop a file here or press Enter to browse."
            data-testid="button-upload-pdf"
            onClick={() => inputRef.current?.click()}
            onKeyDown={(event) => {
              if (event.key === 'Enter' || event.key === ' ') { event.preventDefault(); inputRef.current?.click(); }
            }}
            onDragOver={(event) => { event.preventDefault(); setDragging(true); }}
            onDragLeave={() => setDragging(false)}
            onDrop={(event) => { event.preventDefault(); setDragging(false); void selectFile(event.dataTransfer.files[0]); }}
          >
            <span className="upload-icon"><UploadCloud size={25} strokeWidth={2} /></span>
            <span className="drop-title">Drop your PDFs here or <span className="browse-link">browse files</span></span>
            <span className="drop-sub">PDF files only · Maximum file size 200 MB</span>
          </div> : <div className="control-panel">
            <div className="section-heading"><h2>Your document</h2><span className="subtle-label">{parsing ? 'Reading PDF…' : pageCount ? `${pageCount} ${pageCount === 1 ? 'page' : 'pages'} detected` : 'Preparing file'}</span></div>
            <div className="file-row" data-testid="text-selected-file">
              <span className="pdf-icon"><FileText size={22} /></span>
              <div className="file-meta"><div className="file-name">{file.name}</div><div className="file-details">{sizeLabel(file.size)}{pageCount ? ` · ${pageCount} pages` : parsing ? ' · Checking page count' : ''}</div></div>
              {!splitting && <button type="button" className="icon-button" onClick={reset} aria-label="Remove file and start over" data-testid="button-remove-file"><X size={18} /></button>}
            </div>
            <div className="section-heading"><h2>How should we split it?</h2></div>
            <div className="mode-list" role="radiogroup" aria-label="Split method">
              <div className={`mode-option${mode === 'pages' ? ' selected' : ''}`} role="radio" aria-checked={mode === 'pages'} tabIndex={0} onClick={() => selectMode('pages')} onKeyDown={(event) => { if (event.key === 'Enter' || event.key === ' ') selectMode('pages'); }}>
                <span className="radio-dot" /><div className="mode-copy"><div className="mode-title">Every page separately</div><div className="mode-description">Create one PDF for each page in your document.</div></div>
              </div>
              <div className={`mode-option${mode === 'ranges' ? ' selected' : ''}`} role="radio" aria-checked={mode === 'ranges'} tabIndex={0} onClick={() => selectMode('ranges')} onKeyDown={(event) => { if (event.key === 'Enter' || event.key === ' ') selectMode('ranges'); }}>
                <span className="radio-dot" /><div className="mode-copy"><div className="mode-title">Custom page ranges</div><div className="mode-description">Choose the page groups you want in each PDF.</div>
                  {mode === 'ranges' && <div className="mode-input-wrap"><label className="field-label" htmlFor="page-ranges">Page ranges</label><input id="page-ranges" className="text-input" type="text" value={ranges} placeholder="For example: 1-3, 4-5" aria-describedby="ranges-hint ranges-error" data-testid="input-page-ranges" onClick={(event) => event.stopPropagation()} onChange={(event) => setRanges(event.target.value)} /><div className="field-hint" id="ranges-hint">Separate ranges with commas. Pages must be from 1 to {pageCount ?? '…'}.</div>{rangeError && <div className="validation-message" id="ranges-error" role="alert">{rangeError}</div>}</div>}
                </div>
              </div>
              <div className={`mode-option${mode === 'count' ? ' selected' : ''}`} role="radio" aria-checked={mode === 'count'} tabIndex={0} onClick={() => selectMode('count')} onKeyDown={(event) => { if (event.key === 'Enter' || event.key === ' ') selectMode('count'); }}>
                <span className="radio-dot" /><div className="mode-copy"><div className="mode-title">Every N pages</div><div className="mode-description">Split into evenly sized groups of pages.</div>
                  {mode === 'count' && <div className="mode-input-wrap"><label className="field-label" htmlFor="pages-per-file">Pages per PDF</label><input id="pages-per-file" className="text-input" type="number" min="1" step="1" value={pagesPerFile} aria-describedby="count-hint count-error" data-testid="input-pages-per-file" onClick={(event) => event.stopPropagation()} onChange={(event) => setPagesPerFile(event.target.value)} /><div className="field-hint" id="count-hint">The final PDF may contain fewer pages.</div>{countError && <div className="validation-message" id="count-error" role="alert">{countError}</div>}</div>}
                </div>
              </div>
            </div>
            <div className="action-row">
              <div className="secure-note"><ShieldCheck size={15} /> Your file is processed locally — never uploaded.</div>
              <button type="button" className="primary-button" onClick={() => void splitPdf()} disabled={!pageCount || parsing || splitting || !groups || !!rangeError || !!countError} data-testid="button-split-pdf">
                {splitting ? <><Files size={16} /> Splitting…</> : <><Files size={16} /> Split PDF</>}
              </button>
            </div>
            {splitting && <div className="progress-area" role="status" aria-live="polite" data-testid="status-split-progress"><div className="progress-top"><span>Preparing your PDFs</span><span>{progress}%</span></div><div className="progress-track"><div className="progress-fill" style={{ width: `${progress}%` }} /></div></div>}
            {results.length > 0 && !splitting && <div className="result-panel" aria-live="polite" data-testid="status-split-success">
              <div className="result-heading"><h3><Check size={17} /> Your PDFs are ready</h3><span className="result-count">{results.length} {results.length === 1 ? 'file' : 'files'}</span></div>
              <div className="result-list">{results.map((result, index) => <div className="result-row" key={`${result.name}-${index}`} data-testid={`row-result-${index}`}>
                <FileText size={17} className="result-file-icon" /><span className="result-name">{result.name}</span><span className="result-size">{sizeLabel(result.size)}</span><button type="button" className="download-link" onClick={() => download(result.url, result.name)} data-testid={`button-download-${index}`}><ArrowDownToLine size={14} /> Download</button>
              </div>)}</div>
              <div className="result-footer"><button type="button" className="secondary-button" onClick={() => download(zipUrl, `${file.name.replace(/\.pdf$/i, '') || 'document'}_split.zip`)} disabled={!zipUrl} data-testid="button-download-all"><Package size={16} /> Download all as ZIP</button></div>
            </div>}
          </div>}
          {error && <div className="error-banner" role="alert" data-testid="status-upload-error"><AlertCircle size={17} /><span>{error}</span></div>}
        </section>
        <p className="privacy-note"><LockKeyhole size={14} /> Your files never leave this device. They’re processed securely in your browser and automatically cleared from DocShift when you reset or close this page.</p>
      </main>
      <footer className="footer">DocShift · Private PDF tools, made simple.</footer>
    </div>
  );
}

function Router() {
  return <RoutedErrorBoundary><Switch><Route path="/" component={Home} /><Route component={NotFound} /></Switch></RoutedErrorBoundary>;
}
function RoutedErrorBoundary({ children }: { children: ReactNode }) {
  const [location] = useLocation();
  return <ErrorBoundary resetKey={location}>{children}</ErrorBoundary>;
}
function App() {
  return <QueryClientProvider client={queryClient}><TooltipProvider><WouterRouter base={import.meta.env.BASE_URL.replace(/\/$/, '')}><Router /></WouterRouter><Toaster /></TooltipProvider></QueryClientProvider>;
}
export default App;
